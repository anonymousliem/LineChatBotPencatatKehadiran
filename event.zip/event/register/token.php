<?php
$token = $_GET['token'];

echo "<b><h1>".$token."</h1></b>" . " ini adalah token anda harap disimpan dan dibawah ketika pendaftaran.";
echo"<br><br>";
echo"balik ke menu regis " . "<a href='../register/index.php'>" . "klik disini"
?>